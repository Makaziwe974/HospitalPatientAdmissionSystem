/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.medicare.hospital;

/**
 *
 * @author Student
 */
public class HospitalPatientAdmissionSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
